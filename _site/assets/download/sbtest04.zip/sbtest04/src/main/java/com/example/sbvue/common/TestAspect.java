package com.example.sbvue.common;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Slf4j
public class TestAspect {

    @Before("execution(* com.example.sbvue.*.*.*getProduct*(..))")
    public void onBeforeHandler(JoinPoint joinPoint) {
        log.info("=============== onBeforeHandler");
    }

    @After("execution(* com.example.sbvue.*.*.*getProduct*(..))")
    public void onAfterHandler(JoinPoint joinPoint) {
        log.info("=============== onAfterHandler");
    }

    @AfterThrowing(pointcut = "execution(* com.example.sbvue.*.*.*getProduct*(..))", throwing="exception")
    public void onAfterThrowing(JoinPoint thisJoinPoint, Exception exception) {
        log.info("=============== onAfterThrowing : " + exception);
    }

    @AfterReturning(pointcut = "execution(* com.example.sbvue.*.*.*getProduct*(..))", returning = "ret")
    public void onAfterReturning(JoinPoint joinPoint, Object ret) {
        log.info("=============== onAfterReturning : " + ret);
    }

    //@Pointcut("execution(* com.example.sbvue.*.*.*getProduct*(..))")


    @Around("execution(* com.example.sbvue.*.*.*getProduct*(..))")
    public Object onArround(ProceedingJoinPoint pjp) throws Throwable {
        log.info("=============== onArround::Start..." + pjp.getSignature().getDeclaringTypeName() + " / " + pjp.getSignature().getName());
        Object result = pjp.proceed();
        log.info("=============== onArround::End..." + pjp.getSignature().getDeclaringTypeName() + " / " + pjp.getSignature().getName());
        return result;
    }
}
