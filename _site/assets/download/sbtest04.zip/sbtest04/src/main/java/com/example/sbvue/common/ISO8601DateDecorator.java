package com.example.sbvue.common;

import com.fasterxml.jackson.databind.MappingJsonFactory;
import com.fasterxml.jackson.databind.util.StdDateFormat;
import net.logstash.logback.decorate.JsonFactoryDecorator;

public class ISO8601DateDecorator implements JsonFactoryDecorator {
    @Override
    public MappingJsonFactory decorate(MappingJsonFactory mappingJsonFactory) {
        mappingJsonFactory.getCodec().setDateFormat(StdDateFormat.getDateTimeInstance());
        return mappingJsonFactory;
    }
}
