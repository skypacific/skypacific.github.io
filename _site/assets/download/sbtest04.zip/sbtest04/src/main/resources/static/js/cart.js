export default Vue.component('cart', {
        template: '<v-container fluid grid-list-lg>' +
            '        <v-alert :value="cartItems.length <= 0" type="warning">' +
            '            Shopping cart is empty !' +
            '        </v-alert>' +
            '        <v-card :value="cartItems.length > 0" v-for="product in cartItems" :key="product.id">' +
            '            <v-layout row>' +
            '                <v-flex xs3>' +
            '                    <v-img contain :src="product.imgsrc" height="72px" transition="false"></v-img>' +
            '                </v-flex>' +
            '                <v-flex xs9>' +
            '                    <div>' +
            '                        <div class="subheading font-weight-medium">' +
            '                            {{ product.title }} : $ {{ product.price }} x {{ product.quantity }}' +
            '                        </div>' +
            '                        <div>($ {{ product.subtotal }})</div>' +
            '                    </div>' +
            '                </v-flex>' +
            '            </v-layout>' +
            '        </v-card>' +
            '        <div><p></p></div>' +
            '        <v-chip v-if="cartItems.length > 0" color="success" @click="checkOut()">' +
            '            <v-avatar><v-icon>local_grocery_store</v-icon></v-avatar>' +
            '            Total Amount : $ {{ totalAmount }}' +
            '        </v-chip>' +
            '    </v-container>',
        computed: {
            cartItems: function () {
                return this.$store.state.cartItems;
            },
            totalAmount: function () {
                return this.$store.state.totalAmount;
            }
        },
        methods: {
            checkOut: function () {
            }
        }
});
