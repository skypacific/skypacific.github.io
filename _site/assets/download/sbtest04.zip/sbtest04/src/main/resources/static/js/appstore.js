export default new Vuex.Store({
        state: {
            products: [
                {id:1, title:'Apple iPad (Wi-Fi, 32GB) - Space Gray', price:350, inventory:7, imgsrc:'https://images-na.ssl-images-amazon.com/images/I/51x4j48wCpL._SL1024_.jpg'},
                {id:2, title:'Apple iPhone XR (64GB) - RED', price:749, inventory:5, imgsrc:'https://images-na.ssl-images-amazon.com/images/I/51YXG1bDM5L._SL1024_.jpg'},
                {id:3, title:'Apple Macbook Retina Display Laptop', price:949, inventory:2, imgsrc:'https://images-na.ssl-images-amazon.com/images/I/819zx3uAjhL._SL1500_.jpg'},
            ],
            cartItems: [],
            totalAmount: 0
        },
        mutations: {
            setProducts: function(state, products) {
                state.products = products;
            },
            addToCart: function(state, product) {
                state.products
                    .filter(function (p) {
                        return p.id === product.id
                    })
                    .map(function (p) {
                        return p.inventory--
                    });

                var _cartItem = state.cartItems.filter(function (p) {
                    return p.id === product.id
                });
                if (_cartItem.length > 0) {
                    _cartItem.map(function (p) {
                        return p.quantity++
                    });
                } else {
                    state.cartItems.push({
                        "id": product.id,
                        "title": product.title,
                        "price": product.price,
                        "quantity": 1,
                        "imgsrc": product.imgsrc
                    });
                }

                state.cartItems.map(function (p) {
                    p.subtotal = p.price * p.quantity;
                    return p;
                });

                state.totalAmount = state.cartItems.reduce(function (previousSum, currentItem) {
                    return previousSum + currentItem.price * currentItem.quantity;
                }, 0);
            }
        }
});
