export default Vue.component('product', {
    template: '<v-container fluid grid-list-lg>' +
        '        <v-card v-for="product in products" :key="product.id">' +
        '            <v-layout row>' +
        '                <v-flex xs3>' +
        '                    <v-img contain :src="product.imgsrc" height="72px" transition="false"></v-img>' +
        '                </v-flex>' +
        '                <v-flex xs9>' +
        '                    <div>' +
        '                        <div class="subheading font-weight-medium">' +
        '                            {{ product.title }} : $ {{ product.price }}' +
        '                        </div>' +
        '                        <div>(Stock: {{ product.inventory }})</div>' +
        '                    </div>' +
        '                </v-flex>' +
        '                <v-flex xs3>' +
        '                    <v-btn color="primary" fab small dark :disabled="product.inventory <= 0"' +
        '                           @click="addToCart(product)">' +
        '                        <v-icon>add</v-icon>' +
        '                    </v-btn>' +
        '                </v-flex>' +
        '            </v-layout>' +
        '        </v-card>' +
        '    </v-container>',
    computed: {
        products: function () {
            return this.$store.state.products;
        }
    },
    methods: {
        addToCart: function (product) {
            this.$store.commit('addToCart', product)
        }
    },
    mounted: function () {
        var PRODUCT_API_URL = "/product/";
        var _app = this;

        axios.get(PRODUCT_API_URL)
            .then(function (response) {
                _app.$store.state.products = response.data;
            })
            .catch(function (error) {
                console.log(error);
            })
    }
});
