import product from './product.js'
import cart from './cart.js'

export default new VueRouter({
        routes: [
            {path: '/', redirect: '/product'},
            {path: '/product', component: product},
            {path: '/cart', component: cart}
        ]
});
