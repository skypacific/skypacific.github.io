package com.example.sbvue;

import com.example.sbvue.product.Product;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SBVueApplicationTests {

    @Test
    public void contextLoads() {

        Product product = Product.builder()
                .id(1L)
                .title("iPad Mini 12'' 128GB")
                .price(1200)
                .inventory(5)
                .build();

        Assertions.assertThat(product).isNotNull();
        Assertions.assertThat(product.getTitle()).isEqualTo("iPad Mini 12'' 128GB");
    }
}

