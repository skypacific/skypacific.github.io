<template>
    <div>
        <h1>Hello World !</h1>
    </div>
</template>

<style scoped>
    h1 {
        color: red;
    }
</style>
