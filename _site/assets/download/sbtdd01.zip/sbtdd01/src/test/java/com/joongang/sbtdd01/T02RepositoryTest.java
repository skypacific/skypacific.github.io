package com.joongang.sbtdd01;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class T02RepositoryTest {

    @Autowired
    ProductRepository productRepository;

    @Test
    public void t01_when_savedomain_except_notnull() {
        //act
        Product product = new Product(1L, "iPad mini 64GB", 500.20, 5);

        Product persistProduct = productRepository.save(product);

        //assert
        Assertions.assertThat(persistProduct).isNotNull();
        Assertions.assertThat(persistProduct.getId()).isEqualTo(1L);
        Assertions.assertThat(persistProduct.getTitle()).isEqualTo("iPad mini 64GB");
    }
}
