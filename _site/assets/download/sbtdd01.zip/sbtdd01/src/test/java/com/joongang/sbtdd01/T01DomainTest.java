package com.joongang.sbtdd01;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class T01DomainTest {

    @Test
    public void t01_when_createdomain_except_notnull() {
        //act
        Product product = new Product(1L, "iPad mini 64GB", 500.20, 5);

        //assert
        Assertions.assertThat(product).isNotNull();
        Assertions.assertThat(product.getId()).isEqualTo(1L);
        Assertions.assertThat(product.getTitle()).isEqualTo("iPad mini 64GB");
    }

}
