package com.joongang.sbtdd01;

import org.assertj.core.api.Assertions;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class T03ControllerTest {

    @MockBean
    private ProductController productController;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void t01_when_getallproducts_except_productlist() {
        //arrange
        given(productController.getAllProducts()).willReturn(
                Lists.newArrayList(
                        new Product(1L, "iPad mini 64GB", 500.20, 5),
                        new Product(2L, "iPad Pro 128GB", 500.20, 5),
                        new Product(3L, "MacBook Pro Retina 256GB", 500.20, 5)
                ));

        //act
        ResponseEntity<Product[]> response = restTemplate
                .getForEntity("/products", Product[].class);

        //assert
        Assertions.assertThat(response).isNotNull();
        Assertions.assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        Product[] products = response.getBody();
        Assertions.assertThat(products).isNotNull();
        Assertions.assertThat(products.length).isGreaterThan(0);
        Assertions.assertThat(products[0].getId()).isEqualTo(1L);
        Assertions.assertThat(products[0].getTitle()).isEqualTo("iPad mini 64GB");
    }
}
