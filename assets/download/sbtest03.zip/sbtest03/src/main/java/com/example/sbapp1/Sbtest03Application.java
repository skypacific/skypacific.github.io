package com.example.sbapp1;

import com.example.sbapp1.model.Product;
import com.example.sbapp1.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Sbtest03Application {

    @Autowired
    private ProductRepository productRepository;

    /* 1. 상속으로 구현 한 ApplicationRunner 
    //     
    @Component
    public class MyApplicationRunner implements ApplicationRunner {
        @Override
        public void run(ApplicationArguments args) throws Exception {
            productRepository.save(new Product(1, "iPad 4 Mini", 500.01, 2));
            productRepository.save(new Product(2, "H&M T-Shirt White", 10.99, 10));
            productRepository.save(new Product(3, "Charli XCX - Sucker CD", 19.99, 5));
        }
    }
    */

    /*
    // 2. Bean으로 구현 한 ApplicationRunner
    @Bean
    public ApplicationRunner appRunner() {
        return new ApplicationRunner() {
            @Override
            public void run(ApplicationArguments args) throws Exception {
                productRepository.save(new Product(1, "iPad 4 Mini", 500.01, 2));
                productRepository.save(new Product(2, "H&M T-Shirt White", 10.99, 10));
                productRepository.save(new Product(3, "Charli XCX - Sucker CD", 19.99, 5));
            }
        };
    }
    */
    
    // 3. 람다식으로 구현한 applicationRunner
    @Bean
    public ApplicationRunner applicationRunner() {
        return args -> {
            productRepository.deleteAll();
            productRepository.save(new Product(1, "iPad 4 Mini", 500.01, 2));
            productRepository.save(new Product(2, "H&M T-Shirt White", 10.99, 10));
            productRepository.save(new Product(3, "Charli XCX - Sucker CD", 19.99, 5));
        };
    }
    
    public static void main(String[] args) {
        SpringApplication.run(Sbtest03Application.class, args);
    }
}

