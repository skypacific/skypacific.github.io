package com.joongang.sbtest02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sbtest02Application {

    public static void main(String[] args) {
        SpringApplication.run(Sbtest02Application.class, args);
    }

}

